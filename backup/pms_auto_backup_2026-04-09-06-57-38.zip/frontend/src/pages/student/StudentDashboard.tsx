import React from 'react';
import { 
  Briefcase, 
  CheckCircle, 
  XCircle, 
  TrendingUp
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useStudentDashboard } from '../../hooks/useDashboard';
import DashboardSkeleton from '../../components/skeletons/DashboardSkeleton';

import ReadinessGauge from '../../components/student/ReadinessGauge';
import StatCard from '../../components/student/StatCard';
import JobTable from '../../components/student/JobTable';
import InterviewPanel from '../../components/student/InterviewPanel';
import Pipeline from '../../components/student/Pipeline';
import CareerResources from '../../components/student/CareerResources';
import AnnouncementsBoard from '../../components/AnnouncementsBoard';
import StudentDrivesWidget from '../../components/student/StudentDrivesWidget';

const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  
  const { data, isLoading: loading, error } = useStudentDashboard();

  const stats = data?.stats || {
    totalJobs: 0, applied: 0, underReview: 0, 
    shortlisted: 0, selected: 0, rejected: 0
  };
  const readiness = data?.readiness || {
    score: 0,
    breakdown: {
      profile: { score: 0, max: 25 },
      academic: { score: 0, max: 20 },
      skills: { score: 0, max: 20 },
      activity: { score: 0, max: 15 },
      placement: { score: 0, max: 20 }
    }
  };
  const jobs = data?.jobs || [];
  const interviews = data?.interviews || [];
  const notifications = data?.notifications || [];

  if (loading) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <div className="flex h-[60vh] items-center justify-center flex-col gap-4 text-center px-4">
        <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-2">
           <XCircle className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-gray-900">Oops! Something went wrong</h3>
        <p className="text-gray-500 max-w-xs">{error instanceof Error ? error.message : 'Failed to load dashboard data. Please try again later.'}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
      {/* 1. Header Section */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div id="pms-tour-welcome">
          <h2 className="text-3xl font-bold text-gray-900 leading-tight tracking-tight">Placement Dashboard</h2>
          <p className="text-sm text-gray-500 mt-1">
            Welcome back, <span className="font-semibold text-blue-600">{user?.name?.split(' ')[0] || 'Student'}</span>. Your placement readiness is being tracked.
          </p>
        </div>
      </header>

      {/* 2. Main Dashboard Grid (12-col) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Row 0: Announcements (Full Width) */}
        <section className="md:col-span-12" id="pms-tour-announcements">
          <AnnouncementsBoard initialAnnouncements={notifications} />
        </section>
        
        {/* Row 1: Readiness Score (8) + Stats (4) */}
        <section className="md:col-span-8" id="pms-tour-readiness">
          <ReadinessGauge score={readiness.score} breakdown={readiness.breakdown} />
        </section>

        <section className="md:col-span-4 h-full" id="pms-tour-stats">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 h-full">
             <StatCard label="Total Jobs" value={stats.totalJobs.toString()} icon={Briefcase} color="bg-blue-50 text-blue-600" />
             <StatCard label="Applied" value={stats.applied.toString()} icon={TrendingUp} color="bg-cyan-50 text-cyan-600" />
             <StatCard label="Selected" value={stats.selected.toString()} icon={CheckCircle} color="bg-emerald-50 text-emerald-600" />
             <StatCard label="Shortlisted" value={stats.shortlisted.toString()} icon={CheckCircle} color="bg-purple-50 text-purple-600" />
          </div>
        </section>
 
        {/* Row 2: Job Table (8) + Upcoming Interviews (4) */}
        <section className="md:col-span-8">
          <JobTable initialJobs={jobs} />
        </section>

        <section className="md:col-span-4 h-full">
          <InterviewPanel initialInterviews={interviews} />
        </section>

        {/* Row 3: Pipeline (8) + Career Resources (4) */}
        <section className="md:col-span-8">
           <Pipeline stats={stats} />
        </section>

        <section className="md:col-span-4 h-full space-y-6">
           <StudentDrivesWidget />
           <CareerResources />
        </section>

      </div>
    </div>
  );
};

export default StudentDashboard;
